public var lowercaseCatalog: [String] {
    return showCatalog.map { $0.lowercased() }
}

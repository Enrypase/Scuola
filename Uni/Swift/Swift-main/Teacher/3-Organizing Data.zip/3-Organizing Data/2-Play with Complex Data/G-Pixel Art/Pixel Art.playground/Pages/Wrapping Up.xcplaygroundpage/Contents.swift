/*:
 ## Wrapping Up

 In this playground, you applied all your skills to create pixel art and animations. You saw a practical application for many of the concepts you practiced in this unit, such as functions with parameters and structs. The more programming tools you acquire, the easier it is to express yourself in creative ways. With the advent of personal technology, the world of artistic expression has gained one more medium. Congratulations on joining the computer art community! As you continue your programming journey, think about other creative ways you can apply your skills.

 [Previous](@previous)  |  page 10 of 13  |  [Next: Exercise: Emoji](@next)
*/